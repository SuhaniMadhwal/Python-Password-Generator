

import string
import random

class PasswordGenerator:
    def __init__(self):
        self.character_sets = {
            'lowercase': string.ascii_lowercase,
            'uppercase': string.ascii_uppercase,
            'digits': string.digits,
            'special': "!@#$%^&*()"
        }

    def generate_random_password(self, object_name, include_lower=True, include_upper=True, include_digits=True, include_special=True):
        print(f"Enter password criteria for {object_name}:")
        if include_lower:
            min_lowercase = int(input("Minimum lowercase letters: "))
        else:
            min_lowercase = 0
        if include_upper:
            min_uppercase = int(input("Minimum uppercase letters: "))
        else:
            min_uppercase = 0
        if include_digits:
            min_digits = int(input("Minimum digits: "))
        else:
            min_digits = 0
        if include_special:
            min_special = int(input("Minimum special characters: "))
        else:
            min_special = 0
        
        total_min_chars = min_lowercase + min_uppercase + min_digits + min_special
        
        while True:
            length = int(input(f"Enter total password length for {object_name} (must be >= {total_min_chars}): "))
            if length >= total_min_chars:
                break
            else:
                print(f"Password length must be at least {total_min_chars} characters.")
        
        password_chars = (
            random.choices(self.character_sets['lowercase'], k=min_lowercase) if include_lower else [] +
            random.choices(self.character_sets['uppercase'], k=min_uppercase) if include_upper else [] +
            random.choices(self.character_sets['digits'], k=min_digits) if include_digits else [] +
            random.choices(self.character_sets['special'], k=min_special) if include_special else []
        )

        if len(password_chars) < length:
            all_chars = ''.join(self.character_sets.values())
            password_chars += random.choices(all_chars, k=length - len(password_chars))

        random.shuffle(password_chars)
        password = ''.join(password_chars)
        return password

    def evaluate_password_strength(self, password):
        has_lowercase = any(char.islower() for char in password)
        has_uppercase = any(char.isupper() for char in password)
        has_digit = any(char.isdigit() for char in password)
        has_special = any(char in string.punctuation for char in password)
        
        if len(password) >= 8 and has_lowercase and has_uppercase and has_digit and has_special:
            return "Strong"
        elif len(password) >= 6 and (has_lowercase or has_uppercase) and (has_digit or has_special):
            return "Moderate"
        else:
            return "Weak"

class PasswordManager:
    def __init__(self):
        self.passwords = {}

    def add_user_password(self, user_name, password):
        self.passwords[user_name] = password

    def save_passwords_to_file(self, file_name):
        with open(file_name, "w") as file:
            for user, password in self.passwords.items():
                file.write(f"{user}: {password}\n")

    def load_passwords_from_file(self, file_name):
        with open(file_name, "r") as file:
            for line in file:
                user, password = line.strip().split(": ")
                self.passwords[user] = password

def main():
    password_generator = PasswordGenerator()
    password_manager = PasswordManager()

    num_users = int(input("Enter the number of users: "))
    for i in range(1, num_users + 1):
        user_name = input(f"Enter the name of user {i}: ")
        include_lower = input("Include lowercase letters? (y/n): ").lower() == 'y'
        include_upper = input("Include uppercase letters? (y/n): ").lower() == 'y'
        include_digits = input("Include digits? (y/n): ").lower() == 'y'
        include_special = input("Include special characters? (y/n): ").lower() == 'y'
        
        generated_password = password_generator.generate_random_password(user_name, include_lower, include_upper, include_digits, include_special)
        password_strength = password_generator.evaluate_password_strength(generated_password)
        print(f"Generated Password for {user_name}: {generated_password} (Strength: {password_strength})")
        password_manager.add_user_password(user_name, generated_password)

    file_name = "passwords.txt"
    password_manager.save_passwords_to_file(file_name)
    print(f"Passwords saved to {file_name}")

if __name__ == "__main__":
    main()

